#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

/*
        Justin Turziak Program1-Part2B

        Compile: 
            1: make 
            2: gcc -g -Wall -o tsh tsh.c
        Run: 
            1: ./tsh -execlp 
            2: ./tsh -execvp
            3: ./tsh (same as ./tsh -execvp)
*/

struct Node
{
    char* data;
    struct Node* next;
}*head = NULL; //global


void insert(struct Node* h, char* token)
{
    if(h->data == NULL)
    {
        h->data = token;
        h->next = NULL;
        return;
    }
    struct Node* temp;
    temp = malloc(sizeof(struct Node));

    temp->data = token;
    temp->next = head;
    head = temp;
  
}

void history(struct Node* h)
{
    while(h != NULL)
    {
        printf("%s\n", h->data);
        h = h->next;
    }
}

int main(int argc, char* argv[])
{
    char error_message[] = "An error has occurred from JT\n";
    char* buffer = NULL;
    size_t size;
    pid_t pid;
    int result = 0;
    char* pieceAfterToken[5] = {NULL};
    int piece = sizeof(pieceAfterToken) / sizeof(pieceAfterToken[0]);

    char* searchPath[32] = {NULL}; //not sure how to dynamically allocate memory
    int pathSize = sizeof(searchPath) / sizeof(searchPath[0]);

    char* cdArray[32] = {NULL};
    int cdsize = sizeof(cdArray) / sizeof(cdArray[0]);

    char cdTemp[32];
    
    if(argc > 2)
    {
        perror("\nUSAGE-- the maximum number of command line arguments is 2...\n");
        exit(1);
    }

    head = (struct Node*)malloc(sizeof(struct Node));
    head->data = NULL;
    head->next = NULL;
    
    if(argc == 2 && strcmp("-execlp", argv[1]) == 0)
    {
               while(1)
                {
                    printf("tsh> ");

                    getline(&buffer, &size, stdin);
                    char* cmdBuffer = buffer;
                    
                    //reset the piece of the buffer after first command
                    for(int i = 0; i < piece; i++)
                    {
                        pieceAfterToken[i] = NULL;
                    }

                    //remove \n from end of buffer found it annoying later on
                    char* newlineToken = strtok(cmdBuffer, "\n");

                    for(int i = 0; newlineToken != NULL; i++)
                    {
                        pieceAfterToken[i] = newlineToken;
                        newlineToken = strtok(NULL, " ");
                    }

                    /* string parse to get rest of path */
                    char* token = strtok(cmdBuffer, " ");
           
                    for(int i = 0; token != NULL; i++)
                    {
                        pieceAfterToken[i] = token;
                        token = strtok(NULL, " ");
                    }

                    char* cmd = strtok(buffer, " ");

                    //cd needs 1 and only 1 argument
                    if((strcmp(cmd, "cd") == 0) && (pieceAfterToken[1] == NULL || pieceAfterToken[2] != NULL)) 
                    {
                        write(STDERR_FILENO, error_message, strlen(error_message));
                        continue;
                    }
                    
                    if(strcmp("exit", cmd) == 0)
                    {   
                        exit(0);
                    }
                    else if(strcmp("path", cmd) == 0)
                    {
                        
                        if((pieceAfterToken[1] == NULL) && (searchPath[0] == NULL)) //no path entered
                        {
                            insert(head, "path");

                            printf("path is set to none\n");
                            continue;
                        }
                       
                        for(int i = 0; i < pathSize; i++) //new path overrides start fresh
                        {
                            searchPath[i] = NULL;
                        }
                        
                        char* path = pieceAfterToken[1];


                        char* token = strtok(path, ":");        

                        for(int i = 0; token != NULL; i++)
                        {
                            searchPath[i] = token;
                            token = strtok(NULL, ":");               
                        }
                        
                        //check that each argument in path is valid directory
                        for(int i = 0; (i < pathSize) && (searchPath[i] != NULL); i++) 
                        {
                            result = access(searchPath[i], X_OK);

                            if(result == -1)
                            {
                                write(STDERR_FILENO, error_message, strlen(error_message));
                                break;
                            }
                        }

                        //continue shell after error message
                        if(result == -1)
                        {
                            continue;
                        }

                        if(searchPath[0] != NULL)
                        {
                            printf("path is set to ");
                            for(int i = 0; searchPath[i] != NULL; i++)
                            {
                                if(searchPath[i+ 1] == NULL)
                                {
                                    printf("%s", searchPath[i]);
                                    break;
                                }

                                printf("%s:", searchPath[i]);
                            } 
                        } 
                        insert(head, pieceAfterToken[0]);
                        printf("\n");
                        continue;
                        
                    }
                    else if((strcmp("cd", cmd) == 0) && (pieceAfterToken[1] != NULL))
                    {
                        //start fresh cd
                        for(int i = 0; i < cdsize; i++)
                        {
                            cdArray[i] = NULL;
                        }                   
                        
                        //get part of string to tokenize after cd 
                        char* cd = pieceAfterToken[1];
                        
                        char* token = strtok(cd, "/");        

                        for(int i = 0; token != NULL; i++)
                        {
                            cdArray[i] = token;
                            token = strtok(NULL, "/");             
                        }
                        
                        //cdTemp array holds each token with a dash i.e. temp[0] = /bin temp[1] = /etc ... 
                        for(int i = 0; cdArray[i] != NULL; i++)
                        {
                           
                            strcpy(cdTemp, "/");

                            strcat(cdTemp, cdArray[i]);

                            result = chdir(cdTemp);

                            if(result == -1)
                            {
                                write(STDERR_FILENO, error_message, strlen(error_message));
                                break;
                            }
                           
                            printf("%s", cdTemp);     
                        }  

                        //continue tsh shell after the error message
                        if(result == -1)
                        {
                            continue;
                        } 

                        printf("/");
                        continue;
                                   
                    }
                    else if(strcmp("cat", cmd) == 0)
                    {
                        
                        if(pieceAfterToken[1] == NULL) //reads user input since no args
                        {
                            char* tempBuffer = NULL;
                            size_t size;

                            getline(&tempBuffer, &size, stdin);

                            printf("%s", tempBuffer);
                        }
                        else if(strcmp(pieceAfterToken[1], "<") == 0)
                        {
                            int result = access(pieceAfterToken[2], R_OK);

                            if(result == -1)
                            {
                                write(STDERR_FILENO, error_message, strlen(error_message));
                                continue;
                            }
                            else
                            {
                                FILE* readfp = fopen(pieceAfterToken[2], "r");
                                char buffer[1024];

                                if(readfp == NULL)
                                {
                                    write(STDERR_FILENO, error_message, strlen(error_message));
                                    continue;
                                }
                                else
                                {
                                    while(fgets(buffer, sizeof(buffer), readfp) != NULL)
                                    {
                                        printf("%s", buffer);
                                    }
                                }

                                fclose(readfp);
                            }
                        }
                    }
                    else if((strcmp("history", cmd) == 0)) //no argument
                    {
                        if(pieceAfterToken[2] != NULL) //too many args
                        {
                            write(STDERR_FILENO, error_message, strlen(error_message));
                            continue;
                        }
                        if(pieceAfterToken[1] == NULL) //no args
                        {
                            insert(head, pieceAfterToken[0]);
                            history(head);
                        }
                    }
                    else //external commands
                    {
                        //path is empty shell should be able to run any external cmds
                        if(searchPath[0] == NULL)
                        {
                            continue;
                        }
                        
                        //execlp() is limited to 4 cmds
                        if(pieceAfterToken[4] != NULL)
                        {
                            write(STDERR_FILENO, error_message, strlen(error_message));
                            continue;
                        }

                        pid = fork();
                        if(pid == 0) //child process
                        {
                        
                            if(pieceAfterToken[1] == NULL) //only one command i.e ls
                            {
                                int accessResult;
                                for(int i = 0; (searchPath[i] != NULL) && (i < pathSize); i++)
                                {
                                    char temp[100];
                                    strcpy(temp, searchPath[i]);
                                    strcat(temp, "/");
                                    strcat(temp, cmd);
                                
                                    accessResult = access(temp, X_OK);

                                    if(accessResult != -1)
                                    {
                                        
                                        result = execlp(cmd, cmd, NULL);
                                            
                                        //return value error from execlp()
                                        if(result == -1)
                                        {
                                            write(STDERR_FILENO, error_message, strlen(error_message));
                                            break;
                                        }
                                        
                                        break;
                                    }
                                }

                                //execlp() never called, no paths work with cmd according to access()
                                write(STDERR_FILENO, error_message, strlen(error_message));
                                break;         
                                
                            }
                            else //more than one external command
                            {
                                result = execlp(
                                            cmd, cmd, pieceAfterToken[1], pieceAfterToken[2], pieceAfterToken[3], NULL);

                                //return value error from execlp()
                                if(result == -1)
                                {
                                    write(STDERR_FILENO, error_message, strlen(error_message));
                                    break;
                                }
                            }
                        }
                        else if(pid > 0) //parent process
                        {
                            int status;
                            pid_t result = wait(&status);

                            if(result == -1)
                            {
                                //return value error from wait
                                write(STDERR_FILENO, error_message, strlen(error_message));
                            }
                        }
                        else
                        {
                            //return value error from fork
                            write(STDERR_FILENO, error_message, strlen(error_message));
                        }
                    }
                }       
    }
    else if((argc == 2 && strcmp("-execvp", argv[1]) == 0) || (argc == 1)) //execvp by default if no second arg
    {       
        while(1)
                {
                    printf("tsh> ");

                    getline(&buffer, &size, stdin);
                    char* cmdBuffer = buffer;

                    //reset the piece of the buffer after first command
                    for(int i = 0; i < piece; i++)
                    {
                        pieceAfterToken[i] = NULL;
                    }

                    //remove \n from end of buffer found it annoying later on
                    char* newlineToken = strtok(cmdBuffer, "\n");

                    for(int i = 0; newlineToken != NULL; i++)
                    {
                        pieceAfterToken[i] = newlineToken;
                        newlineToken = strtok(NULL, " ");
                    }

                    /* string parse to get rest of path */
                    char* token = strtok(cmdBuffer, " ");
           
                    for(int i = 0; token != NULL; i++)
                    {
                        pieceAfterToken[i] = token;
                        token = strtok(NULL, " ");
                    }

                    char* cmd = strtok(buffer, " ");

                    //cd needs 1 and only 1 argument
                    if((strcmp(cmd, "cd") == 0) && (pieceAfterToken[1] == NULL || pieceAfterToken[2] != NULL)) 
                    {
                        write(STDERR_FILENO, error_message, strlen(error_message));
                        continue;
                    }
                    
                    if(strcmp("exit", cmd) == 0)
                    {         
                        exit(0);
                    }
                    else if(strcmp("path", cmd) == 0)
                    {
                        
                        if((pieceAfterToken[1] == NULL) && (searchPath[0] == NULL)) //no path entered
                        {
                            printf("path is set to none\n");
                            continue;
                        }
                       
                        for(int i = 0; i < pathSize; i++) //new path overrides start fresh
                        {
                            searchPath[i] = NULL;
                        }
                        
                        char* path = pieceAfterToken[1];

                        char* token = strtok(path, ":");        

                        for(int i = 0; token != NULL; i++)
                        {
                            searchPath[i] = token;
                            token = strtok(NULL, ":");               
                        }
                        
                        //check that each argument in path is valid directory
                        for(int i = 0; (i < pathSize) && (searchPath[i] != NULL); i++) 
                        {
                            result = access(searchPath[i], X_OK);

                            if(result == -1)
                            {
                                write(STDERR_FILENO, error_message, strlen(error_message));
                                break;
                            }
                        }

                        //continue shell after error message
                        if(result == -1)
                        {
                            continue;
                        }

                        if(searchPath[0] != NULL)
                        {
                            printf("path is set to ");
                            for(int i = 0; searchPath[i] != NULL; i++)
                            {
                                if(searchPath[i+ 1] == NULL)
                                {
                                    printf("%s", searchPath[i]);
                                    break;
                                }

                                printf("%s:", searchPath[i]);
                            } 
                        } 
                        printf("\n");
                        continue;
                        
                    }
                    else if((strcmp("cd", cmd) == 0) && (pieceAfterToken[1] != NULL))
                    {
                        //start fresh cd
                        for(int i = 0; i < cdsize; i++)
                        {
                            cdArray[i] = NULL;
                        }                   
                        
                        //get part of string to tokenize after cd 
                        char* cd = pieceAfterToken[1];
                        
                        char* token = strtok(cd, "/");        

                        for(int i = 0; token != NULL; i++)
                        {
                            cdArray[i] = token;
                            token = strtok(NULL, "/");             
                        }
                        
                        //cdTemp array holds each token with a dash i.e. temp[0] = /bin temp[1] = /etc ... 
                        for(int i = 0; cdArray[i] != NULL; i++)
                        {
                           
                            strcpy(cdTemp, "/");

                            strcat(cdTemp, cdArray[i]);

                            result = chdir(cdTemp);

                            if(result == -1)
                            {
                                write(STDERR_FILENO, error_message, strlen(error_message));
                                break;
                            }
                           
                            printf("%s", cdTemp);     
                        }  

                        //continue tsh shell after the error message
                        if(result == -1)
                        {
                            continue;
                        } 

                        printf("/");
                        continue;
                                   
                    }
                    else if(strcmp("cat", cmd) == 0)
                    {
                        
                        if(pieceAfterToken[1] == NULL) //reads user input since no args
                        {
                            char* tempBuffer = NULL;
                            size_t size;

                            getline(&tempBuffer, &size, stdin);

                            printf("%s", tempBuffer);
                        }
                        else if(strcmp(pieceAfterToken[1], "<") == 0)
                        {
                            int result = access(pieceAfterToken[2], R_OK);

                            if(result == -1)
                            {
                                write(STDERR_FILENO, error_message, strlen(error_message));
                                continue;
                            }
                            else
                            {
                                FILE* readfp = fopen(pieceAfterToken[2], "r");
                                char buffer[1024];

                                if(readfp == NULL)
                                {
                                    write(STDERR_FILENO, error_message, strlen(error_message));
                                    continue;
                                }
                                else
                                {
                                    while(fgets(buffer, sizeof(buffer), readfp) != NULL)
                                    {
                                        printf("%s", buffer);
                                    }
                                }

                                fclose(readfp);
                            }
                        }
                    }
                     else if((strcmp("history", cmd) == 0)) //no argument
                    {
                        if(pieceAfterToken[2] != NULL) //too many args
                        {
                            write(STDERR_FILENO, error_message, strlen(error_message));
                            continue;
                        }
                        if(pieceAfterToken[1] == NULL) //no args
                        {
                            insert(head, pieceAfterToken[0]);
                            history(head);
                        }
                    }
                    else //external commands
                    {
                        //path is empty shell should be able to run any external cmds
                        if(searchPath[0] == NULL)
                        {
                            continue;
                        }

                        pid = fork();
                        if(pid == 0) //child process
                        {
                            char* argList[32] = {NULL};
                            for(int i = 0; pieceAfterToken[i] != NULL; i++)
                            {
                                argList[i] = pieceAfterToken[i];
                            }

                            if(pieceAfterToken[1] == NULL) //only one command i.e ls
                            {
                                int accessResult;
                                for(int i = 0; (searchPath[i] != NULL) && (i < pathSize); i++)
                                {
                                    char temp[100];
                                    strcpy(temp, searchPath[i]);
                                    strcat(temp, "/");
                                    strcat(temp, cmd);
                                
                                    accessResult = access(temp, X_OK);

                                    if(accessResult != -1)
                                    {
                                        char* argList[] = {cmd};
                                        result = execvp(cmd, argList);
                                            //cmd, cmd, pieceAfterToken[1], pieceAfterToken[2], pieceAfterToken[3], NULL);

                                        //return value error from execvp()
                                        if(result == -1)
                                        {
                                            write(STDERR_FILENO, error_message, strlen(error_message));
                                            break;
                                        }
                                        
                                        break;
                                    }
                                }

                                //execvp() never called, no paths work with cmd according to access()
                                write(STDERR_FILENO, error_message, strlen(error_message));
                                break;         
                                
                            }
                            else //more than one external command
                            {
                                result = execvp(cmd, argList);

                                //return value error from execlp()
                                if(result == -1)
                                {
                                    write(STDERR_FILENO, error_message, strlen(error_message));
                                    break;
                                }
                            }
                        }
                        else if(pid > 0) //parent process
                        {
                            int status;
                            pid_t result = wait(&status);

                            if(result == -1)
                            {
                                //return value error from wait
                                write(STDERR_FILENO, error_message, strlen(error_message));
                            }
                        }
                        else
                        {
                            //return value error from fork
                            write(STDERR_FILENO, error_message, strlen(error_message));
                        }
                    }
                }       
    }
    else
    {
        perror("\nUSAGE-- invalid command line arguments...\n");
        exit(1);
    }
   
    free(buffer);
    return 0;
}

